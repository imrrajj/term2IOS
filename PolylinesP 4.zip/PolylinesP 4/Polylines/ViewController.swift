//
//  ViewController.swift
//  Polylines


import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {
   
    // -- MARK: Outlets
    @IBOutlet weak var mapView: MKMapView!

    
    // -- MARK: Default functions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        
        //set up the map view
        let coordinate = CLLocationCoordinate2DMake(32.7767,-96.7970)
        let span = MKCoordinateSpan(latitudeDelta: 1, longitudeDelta: 1)
        let region = MKCoordinateRegion(center: coordinate, span: span)
        mapView.setRegion(region, animated: true)
        
        createPolyline()
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    // -- MARK: Polyline Functions
    func createPolyline() {
        // make an array of locations (coordinates)
        var abc = [
            CLLocationCoordinate2DMake(32.7767, -96.7970),       // dallas, texas
            CLLocationCoordinate2DMake(37.7833, -122.4167)      // san francisco, california
        ]
        
        
        // create a polyline
        let polyline = MKPolyline(coordinates: &abc, count: abc.count)
        
        
        // add the polyline to the map
        mapView.add(polyline)


    
    }
    
    
    // -- MARK: UI Nonsense
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        // show the line on the map!
        if (overlay is MKPolyline) {
            
            let renderer = MKPolylineRenderer(overlay: overlay)
            
            // pick a color for your line
            renderer.strokeColor = UIColor.red
            
            // pick a width for your line
            renderer.lineWidth = 4
            
            return renderer
    
        }
    
        return MKOverlayRenderer()

    }

}

